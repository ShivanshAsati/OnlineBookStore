package com.bookstore.entities;

public class User {

}
